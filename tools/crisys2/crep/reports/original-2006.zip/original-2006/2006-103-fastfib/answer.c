#include <stdio.h>

int FibC( int n )
{
  if( n == 0 ) return 0;
  else if( n == 1 ) return 1;
  return( FibC( n-2 ) + FibC( n-1 ) );
}

int FastFibC( int n )
{
  int i;
  int j = 1;
  int z = 0, tmp = 0;

  for( i = 0 ; i < n ; i++ ){
    tmp = j;
    j += z;
    z = tmp;
  }
  return z;
}

main()
{
  int n;

  printf("n = ");
  scanf("%d", &n );

  printf("    Fib( %d ) = %d\n", n, FibC( n ) );
  printf("FastFib( %d ) = %d\n", n, FastFibC( n ) );
}
