/**********************************/
//ex005.c
//$BF~NO!'<+A3?t$rF~NO(B
//$B5!G=!'F~NO$5$l$?@0?t$KBP$9$k(Bsum1,sum2
//     $B$N7k2L$r$=$l$>$lI=<($9$k(B
/**********************************/
//#include <stdio.h>

int sum1(int n)
{
     int sum1, i ;
     
     sum1=0;
     
     for(i=1; i<=n; i++)
        sum1 = sum1 + i;
     
     return sum1 ;

}

/*
main()
{   
     int n;

     printf("$B<+A3?t$rF~NO$7$F$/$@$5$$(B:");
     scanf("%d",&n);

     printf("sum1$B$K$h$kAmOB(B:%d\n", sum1(n));
     printf("sum2$B$K$h$kAmOB(B:%d\n", sum2(n));

     return 0;
}
  */
    
int sum2(int n)
{
     if (n<=0) return 0;
    
     else if (n==1) return 1; 

     else return sum2(n-1)+n;
}
     
