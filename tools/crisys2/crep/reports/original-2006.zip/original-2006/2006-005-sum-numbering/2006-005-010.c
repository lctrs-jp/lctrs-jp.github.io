/****************************************/
// $BI,?\2]Bj#5(B
// ex005.c
// $BF~NO!'@0?t(Bn
// $B=PNO!'(Bsum1(n)$B$H(Bsum2(n)$B$N7k2L$rI=<((B
// $BJQ?t!'(Bn $BI8=`F~NO$+$i(Bn$B$r<u$1<h$k$?$a$NJQ?t(B
/****************************************/

//#include <stdio.h>

//int sum1(int n);
//int sum2(int n);

/*
main()
{
	int n;
	printf("Imput natural number N : ");
	scanf("%d",&n);
	printf("sum1:the sum total of 0 to %d = %d\n",n,sum1(n));
	printf("sum2:the sum total of 0 to %d = %d\n",n,sum2(n));
}
*/

/*--------------------------------------*/
// $B4X?t(B sum1
// $B0z?t!'(Bn (int)
// $BJVCM!'(Bsum (int)
// $B5!G=!'(B0$B$+$i(Bn$B$^$G$NAmOB(Bsum$B$rJV$9!J:F5"IT;HMQ!K(B
//       $B$?$@$7!"(Bn<0$B$N;~$O(B0$B$rJV$9(B
// $BJQ?t!'(Bsum $BAmOB$r5a$a$k$?$a$K;H$&JQ?t(B
/*--------------------------------------*/

int sum1(int n)
{
	int sum=0;
	if(n<0)
	{
		return 0;
	}
	else
	{
		while(n>=0)
		{
			sum+=n;
			n--;
		}
		return sum;
	}
}

/*--------------------------------------*/
// $B4X?t(B sum2
// $B0z?t!'(Bn (int)
// $BJVCM!'(B0$B$+$i(Bn$B$^$G$NAmOB(B (int)
// $B5!G=!'(B0$B$+$i(Bn$B$^$G$NAmOB(Bsum$B$rJV$9!J:F5";HMQ!K(B
//       $B$?$@$7!"(Bn<0$B$N;~$O(B0$B$rJV$9(B
/*--------------------------------------*/

int sum2(int n)
{
	if(n<0)
	{
		return 0;
	}
	else
	{
		if(n==0)
		{
			return 0;
		}
		else
		{
			return n+sum2(n-1);
		}
	}
}
