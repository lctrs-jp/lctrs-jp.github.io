//0$B$+$i(Bn$B$^$G$NAm9g$r7W;;$9$k4X?t(B sum1 sum2//
//#include <stdio.h>
// for $BJ8$r;H$C$F7W;;$9$k(B sum1//
int sum1 (int n){
	int i,s;
	s = 0;
	if (n<0) return 0;
	else {
		for (i = 0;i <= n;i++)
			s = s + i;
		return s;}
}
// $B:F5"8F$S=P$7$r;HMQ$9$k(B sum2//
int sum2 (int n){

	if (n<0) return  0;
	else return n + sum2(n - 1);
}

/*
main () {
	int n;
	printf("$B<+A3?t$rF~NO$7$F$/$@$5$$(B:");
	scanf("%d",&n);
	printf("sum1 $B$K$h$kAmOB(B: %d\n",sum1(n));
	printf("sum2 $B$K$h$kAmOB(B: %d\n",sum2(n));
}
  */
