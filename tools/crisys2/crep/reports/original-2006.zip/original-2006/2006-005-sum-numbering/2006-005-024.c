#include <stdio.h>

int sum1(int n){                       /*$B7+$jJV$79=J8$G$NOB;;(B*/
  int s = 0;
  int i;
  for(i=0;i<=n;i++){
    s = s + i;
  }
  return(s);
}

/*
int main()
{
  int n,s1;
  printf("$B<+A3?t$rF~NO$7$F$/$@$5$$!'(B");
  scanf("%d",&n);
  if(n<=0){
    printf("$B$A$c$s$H<+A3?t$rF~NO$7$F$/$@$5$$$h!#(B\n");$B!!!!(B//$BIT@5F~NO$KBP$9$k=hM}(B
  }else{
    printf("sum1 $B$K$h$kAmOB!'(B %d\nsum2 $B$K$h$kAmOB!'(B %d\n", sum1(n), sum2(n));
  }
  return 0;
}
*/

int sum2(int n){$B!!!!!!!!!!!!!!!!!!!!!!!!!!!!(B/*$B:F5/$rMQ$$$?OB;;(B*/
  if(n==0){
    return(0);
  }else if(n<0){
    return(0);
  }else{
    return(sum2(n-1)+n);
  }
}
