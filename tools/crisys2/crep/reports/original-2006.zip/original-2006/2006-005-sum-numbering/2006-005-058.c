/**************************************
 * $BI,?\1i=,2]Bj#5(B
 * ex005.c
 * $BF~NO!'<+A3?t(B
 * $B5!G=!'(B0$B$+$iF~NO$5$l$?<+A3?t$^$G$NAmOB(B
 *      $B$r=PNO$9$k(B
 *       $BF~NO$,Ii$N;~$O#0$r=PNO$9$k(B
 **************************************/

//#include <stdio.h>

//int sum2(int);

int sum1(int num){
	int sum = 0;
	if(num > 0){
		while(num != 0){
			sum = sum + num;
			num--;
		}
		return sum;
	}else{
		return 0;
	}
}


/*
int main(){
	int input = 0;
	
	printf("$B<+A3?t$rF~NO$7$F$/$@$5$$!'(B");
	scanf("%d", &input);

	printf("sum1 $B$K$h$kAmOB!'(B %d\n", sum1(input));
	printf("sum2 $B$K$h$kAmOB!'(B %d\n", sum2(input));

	return 0;
}
  */

int sum2(int num){
	if(num > 0){
		num = num + sum2(num - 1);
		return num;
	}else{
		return 0;
	}
}

