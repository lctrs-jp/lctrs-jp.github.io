/***************************************/
// ex005.c
// $BF~NO!'@0?t(B
// $B5!G=!'F~NO$5$l$?@0?t$KBP$9$k(Bsum1,sum2$B$N%F%9%H(B
/***************************************/

//#include <stdio.h>

// 1$B$+$i(Bn$B$^$G$NAmOB$rJV$9(B($B:F5";H$o$:(B) 
int sum1(int n){
	int i,sum = 0;

	if (n > 0){
		for(i = 1; i <= n; i++){
			sum += i;
		}
	}
	return (sum);
}

// 1$B$+$i(Bn$B$^$G$NAmOB$rJV$9(B($B:F5";H$&(B)
int sum2(int n){
	if (n < 1){
		return(0);
	} else if (n == 1){
		return(1);
	} else {
		return(n + sum2(n-1));
	}
}

/*
int main(void){
	int num;

	printf("$B<+A3?t$rF~NO$7$F$/$@$5$$!!(B:");
	scanf("%d",&num);

	printf("sum1   %d\n",sum1(num));
	printf("sum2   %d\n",sum2(num));

	return 0;
}
*/
