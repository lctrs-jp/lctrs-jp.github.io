/**************************************/
//  課題5
//  ex005.c
//  入力：整数 n
//  機能： 0 から n までの総和を返す。
/**************************************/
//#include <stdio.h>

//int sum2(int n);

int sum1(int n){
  int x = 0;
  if(n <= 0){
    return 0;
  }
  while(n > 0){            //while文で n が０になるまで繰り返す。
    x += n;
    n--;
  }
  return x;
}

/*
main(){
  int num;
  printf("数字を入力してください：");
  scanf("%d", &num);
  printf("sum1による総和：%d\n", sum1(num));
  printf("sum2による総和：%d\n", sum2(num));
}
  */

int sum2(int n){
  int x;
  if(n <= 0){
    return 0;
  }
  x = n + sum2(n-1);       //nを１ずつ小さくし、足していく。
  return x;
}
